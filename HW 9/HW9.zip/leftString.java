package com.example.kinglunau.hw9;

/**
 * Created by kinglunau on 11/25/17.
 */

public class leftString {
    private String name;



    public leftString(String name) {

        this.name=name;

    }



    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }



}
