package com.example.kinglunau.hw9;

/**
 * Created by kinglunau on 11/25/17.
 */

public class rightString {
    private String name;



    public rightString(String name) {

        this.name=name;

    }



    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }



}
